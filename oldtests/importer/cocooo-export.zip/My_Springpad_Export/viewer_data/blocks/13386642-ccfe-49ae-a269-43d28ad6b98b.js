var block = {
"tags":[],
"created":"2013-02-13T17:19:30+0000",
"item count":5.0,
"liked":false,
"name":"test",
"image":null,
"uuid":"13386642-ccfe-49ae-a269-43d28ad6b98b",
"public":false,
"type":"Notebook",
"modified":"2014-04-07T11:41:17+0000"
};