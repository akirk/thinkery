var block = {
"tags":[],
"liked":false,
"notebooks":["13386642-ccfe-49ae-a269-43d28ad6b98b"],
"image":null,
"type":"Bookmark",
"url":"http:\/\/stackoverflow.com\/questions\/6553758\/in-vim-why-is-j-used-for-down-and-k-for-up",
"modified":"2014-04-09T14:34:41+0000",
"created":"2013-02-13T20:19:47+0000",
"complete":false,
"name":"",
"uuid":"133d85ae-f500-4c0a-9d4f-7eb6cc5efd40",
"rating":0.0,
"public":false
};