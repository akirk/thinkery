var block = {
"tags":["fasfl lasd alsd asd","asasd","asdasd"],
"text":"",
"liked":false,
"notebooks":["13386642-ccfe-49ae-a269-43d28ad6b98b"],
"image":null,
"type":"Note",
"modified":"2014-04-09T14:34:41+0000",
"created":"2013-02-13T17:20:49+0000",
"complete":false,
"name":"Blank Note",
"uuid":"133b3e6d-3600-489b-8c5a-a86f15331812",
"public":false,
"comments":[
    {
    },
    {
    },
    {
    "commenter":"akirk",
    "date":"2013-02-13T17:21:52+0000",
    "comment":"hasjdas"
    },
    {
    "commenter":"cocooo",
    "date":"2013-02-13T17:21:03+0000",
    "comment":"asdasd"
    }]
};