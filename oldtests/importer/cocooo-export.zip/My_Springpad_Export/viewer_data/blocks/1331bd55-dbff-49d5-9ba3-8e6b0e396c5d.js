var block = {
"tags":[],
"complete":false,
"created":"2013-02-13T17:20:51+0000",
"liked":false,
"name":"Blank Note",
"notebooks":["13386642-ccfe-49ae-a269-43d28ad6b98b"],
"image":null,
"uuid":"1331bd55-dbff-49d5-9ba3-8e6b0e396c5d",
"public":false,
"type":"Note",
"modified":"2014-04-09T14:34:41+0000"
};