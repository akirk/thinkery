var block = {
"tags":[],
"text":"hello <b>test<\/b>. test ",
"complete":false,
"created":"2013-02-13T20:19:47+0000",
"liked":false,
"name":"hello test. test ",
"notebooks":["13386642-ccfe-49ae-a269-43d28ad6b98b"],
"image":null,
"uuid":"133cdb4b-2802-47ea-b8cd-01e762ef4b4d",
"public":false,
"type":"Note",
"modified":"2014-04-09T14:34:41+0000"
};