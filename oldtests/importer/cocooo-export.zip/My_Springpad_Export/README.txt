
Springpad Export
================

Hi there! This is your exported data from Springpad. From here you can view
all your data you've saved in a small read-only viewer as well as use the
raw-data to import into other services.


Springpad Viewer
----------------

If you open the "viewer.html" in your web browser you will be able to see
and search all of your data.


Importing & Raw Data
--------------------

In addition to the viewer.html, we've exported all your items' data into a
file called "export.json." Additionally all your attachments, files and
photos are stored in the "/attachments" directory. Using these, you will be
able to import/upload your data into other compatible services.


Good Bye
--------

It's been a pleasure helping you get organized for the past six years.

Thanks,
The Springpad Team
