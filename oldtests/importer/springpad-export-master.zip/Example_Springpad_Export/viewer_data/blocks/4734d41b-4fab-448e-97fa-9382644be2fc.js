var block = {
"tags":[],
"liked":false,
"notebooks":["4733205d-1cdc-41d6-a74f-4aa3f1281e4b","47317160-1118-4a9a-83d9-8c3acfd4b8e7"],
"image":"http:\/\/img.foodnetwork.com\/FOOD\/2006\/12\/06\/ig0802_pumpkin1.jpg",
"type":"Recipe",
"modified":"2014-05-20T17:33:55+0000",
"ingredients":"1\/4 cup dark rum\n1 packet (2 teaspoons) unflavored gelatin powder\n1 (15-ounce can) pumpkin (not pie filling)\n1\/2 cup granulated sugar\n1\/2 cup light brown sugar, lightly packed\n2 extra-large egg yolks\n2 teaspoons grated orange zest\n1\/2 teaspoon ground cinnamon\n1\/4 teaspoon ground nutmeg\n1\/2 teaspoon kosher salt\n1 1\/2 cups cold heavy cream\n1 1\/2 teaspoons pure vanilla extract\nSweetened whipped cream\n8 to 10 chopped ginger cookies\nCrystallized ginger, for decoration, optional",
"directions":"*Place the rum in a heat-proof bowl and sprinkle the gelatin over it. Set aside for 10 minutes for the gelatin to soften.  \n*In a large bowl, whisk together the pumpkin, granulated sugar, brown sugar, egg yolks, orange zest, cinnamon, nutmeg, and salt. Set the bowl of gelatin over a pan of simmering water and cook until the gelatin is clear. Immediately whisk the hot gelatin mixture into the pumpkin mixture. In the bowl of an electric mixer fitted with a whisk attachment, whip the heavy cream and vanilla until soft peaks form. Fold the whipped cream into the pumpkin mixture.  \n*To assemble, spoon some of the pumpkin mixture into parfait glasses, add a layer of whipped cream, then some chopped cookies. Repeat, ending with a third layer of pumpkin. Cover with plastic wrap and refrigerate for 4 hours or overnight. To serve, decorate with whipped cream and slivered crystallized ginger.",
"source":"http:\/\/www.foodnetwork.com\/recipes\/ina-garten\/pumpkin-mousse-parfaits-recipe\/index.html",
"created":"2014-02-05T14:31:49+0000",
"complete":false,
"name":"Pumpkin Mousse Parfaits",
"uuid":"4734d41b-4fab-448e-97fa-9382644be2fc",
"public":true
};