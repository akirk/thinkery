var block = {
"tags":[],
"enabled":true,
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"repeats":
  {
  "text":"every week on sun",
  "repeat every":1,
  "repeats":"Weekly",
  "on days":
    {
    "mon":false,
    "tue":false,
    "wed":false,
    "thu":false,
    "fri":false,
    "sat":false,
    "sun":true
    },
  "type":"Frequency"
  },
"type":"Alarm",
"date":"2018-05-20T16:30:00+0000",
"modified":"2014-05-20T16:06:27+0000",
"created":"2014-05-20T16:06:11+0000",
"complete":false,
"name":"Alarm repeats weekly",
"uuid":"4730d81a-4535-4c0b-b2ae-3f2dd18a1ac3",
"public":true
};