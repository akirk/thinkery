var block = {
"tags":["product-tag"],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":"http:\/\/ecx.images-amazon.com\/images\/I\/21kxmYXoMTL.jpg",
"type":"Product",
"url":"http:\/\/www.pricegrabber.com\/\/search_getprod.php?masterid=892497873",
"modified":"2014-05-19T13:58:14+0000",
"category":"CE",
"price":"$69.00",
"created":"2014-05-19T13:58:04+0000",
"complete":false,
"manufacturer":"Apple Computer",
"description":"New MC184LLB",
"name":"Apple Wireless Keyboard MC184LL\/B [NEWEST VERSION]",
"uuid":"473d2eb9-28f7-4279-9806-1568a9282b9e",
"public":true,
"comments":[
    {
    "commenter":"klmprt",
    "date":"2014-05-19T13:58:06+0000",
    "comment":"I really do love this keyboard."
    }]
};