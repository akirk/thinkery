var block = {
"tags":[],
"liked":false,
"notebooks":["47317160-1118-4a9a-83d9-8c3acfd4b8e7"],
"image":"http:\/\/img4-1.myrecipes.timeinc.net\/i\/recipes\/sl\/10\/04\/raspberry-beer-cocktail-sl-x.jpg",
"type":"Recipe",
"url":"http:\/\/www.myrecipes.com\/recipe\/raspberry-beer-cocktail-10000001975699\/",
"modified":"2014-05-20T17:34:21+0000",
"directions":"1. Stir together first 4 ingredients. Serve over ice. Garnish, if desired.\n\n2. *Fresh raspberries may be substituted.\n\n3. Note: To make ahead, stir together lemonade concentrate and vodka in a large container. Chill up to 3 days. Stir in raspberries and beer just before serving. Garnish, if desired.",
"ingredients":"3\/4 cup  frozen raspberries*\n3 1\/2   (12-oz.) bottles beer, chilled\n1   (12-oz.) container frozen raspberry lemonade concentrate, thawed\n1\/2 cup  vodka\nGarnish: lemon and lime slices",
"source":"http:\/\/www.myrecipes.com\/recipe\/raspberry-beer-cocktail-10000001975699\/",
"created":"2014-05-20T17:34:09+0000",
"complete":true,
"name":"Raspberry Beer Cocktail",
"uuid":"473b4a23-45f1-46da-b4d7-90bae50fcb68",
"public":true
};