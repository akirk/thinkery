var block = {
"tags":[],
"enabled":true,
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"repeats":
  {
  "text":"every day",
  "repeat every":1,
  "repeats":"Daily",
  "type":"Frequency"
  },
"type":"Alarm",
"date":"2017-05-20T16:30:00+0000",
"modified":"2014-05-20T16:07:08+0000",
"created":"2014-05-20T16:06:55+0000",
"complete":false,
"name":"Alarm repeats daily",
"uuid":"4737219a-33e3-4299-b83a-c45ce9021677",
"public":true
};