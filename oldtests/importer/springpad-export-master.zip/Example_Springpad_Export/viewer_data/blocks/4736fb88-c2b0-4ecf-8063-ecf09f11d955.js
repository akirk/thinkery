var block = {
"tags":[],
"liked":false,
"notebooks":["473c76db-e661-4c03-9b8e-bedaafd1cc62"],
"image":"http:\/\/cdn1.nflximg.net\/images\/7903\/2527903.jpg",
"type":"TV Show",
"modified":"2014-02-05T18:33:31+0000",
"plot":"From the creator of \"Weeds\" comes a heartbreaking and hilarious new series set in a women's prison. Piper trades her comfortable life for an orange jumpsuit and finds unexpected conflict and camaraderie amidst an eccentric group of inmates.",
"cast":["Taylor Schilling","Jason Biggs","Laura Prepon","Kate Mulgrew","Danielle Brooks","Pablo Schreiber","Natasha Lyonne","Uzo Aduba","Taryn Manning","Laverne Cox","Yael Stone","Samira Wiley","Dascha Polanco","Matt McGorry","Elizabeth Rodriguez","Selenis Leyva"],
"created":"2014-02-05T18:33:31+0000",
"complete":false,
"name":"Orange Is the New Black",
"uuid":"4736fb88-c2b0-4ecf-8063-ecf09f11d955",
"public":false
};