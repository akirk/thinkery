var block = {
"tags":[],
"created":"2014-03-17T22:08:53+0000",
"item count":3.0,
"liked":false,
"name":"Home Improvement",
"image":null,
"uuid":"473e67fb-e2a5-4952-bc2f-9c7a0ae1f6f0",
"public":false,
"type":"Notebook",
"modified":"2014-05-20T16:10:58+0000"
};