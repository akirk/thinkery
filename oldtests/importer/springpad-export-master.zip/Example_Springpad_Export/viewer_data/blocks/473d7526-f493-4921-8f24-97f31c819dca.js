var block = {
"tags":[],
"enabled":true,
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"repeats":
  {
  "text":"every 2 months on the day",
  "repeat every":2,
  "repeats":"Monthly By Day Of Month",
  "type":"Frequency"
  },
"type":"Alarm",
"date":"2017-05-20T16:30:00+0000",
"modified":"2014-05-20T16:08:00+0000",
"created":"2014-05-20T16:07:11+0000",
"complete":false,
"name":"Alarm repeats every other month",
"uuid":"473d7526-f493-4921-8f24-97f31c819dca",
"public":true
};