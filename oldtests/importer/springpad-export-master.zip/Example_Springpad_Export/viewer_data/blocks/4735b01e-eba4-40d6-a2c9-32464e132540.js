var block = {
"tags":[],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"type":"File",
"url":"attachments\/SourceCodePro-Regular.otf",
"mime-type":"application\/octet-stream",
"modified":"2014-05-20T15:56:32+0000",
"created":"2014-05-20T15:56:09+0000",
"complete":false,
"description":"File description\n",
"name":"(File) SourceCodePro-Regular.otf",
"uuid":"4735b01e-eba4-40d6-a2c9-32464e132540",
"rating":0.0,
"public":true
};