var block = {
"tags":["checklist-tag"],
"items":[
    {
    "complete":false,
    "name":"cl item 1"
    },
    {
    "complete":false,
    "name":"cl item 2"
    },
    {
    "complete":true,
    "name":"cl item 3 (completed)"
    },
    {
    "complete":false,
    "name":"cl item 4"
    }],
"complete":false,
"created":"2014-05-19T13:54:41+0000",
"liked":false,
"name":"checklist",
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"uuid":"473bef74-54ba-4b73-8ac7-5a44f966a495",
"public":true,
"type":"CheckList",
"modified":"2014-05-20T15:51:07+0000"
};