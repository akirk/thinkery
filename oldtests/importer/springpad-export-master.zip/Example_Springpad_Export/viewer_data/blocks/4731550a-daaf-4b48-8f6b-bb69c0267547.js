var block = {
"tags":[],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":"http:\/\/thetvdb.com\/banners\/posters\/75299-6.jpg",
"type":"TV Show",
"plot":"Called \u201Cthe television landmark that leaves other landmarks in the dust,\u201D by the Washington Post, the first part of Season Six was hailed as a masterpiece by critics. In those episodes, Tony Soprano faced new challenges as his life grew increasingly more complicated. Back together with Carmela, he faced the reality that their kids were no longer children, and yet not grown. And with Johnny Sack in prison, the always-tense relations between the New Jersey and New York families were strained even further.",
"modified":"2014-05-20T15:52:41+0000",
"cast":["James Gandolfini","Edie Falco","Dominic Chianese","Federico Castelluccio","Robert Funaro","Michael Imperioli","Joe Pantoliano","David Proval","Lorraine Bracco","Vincent Curatola","Steven Van Zandt","Aida Turturro","Drea de Matteo","Tony Sirico","Robert Iler","Jamie-Lynn Sigler","Nancy Marchand","Vincent Pastore","Steve Schirripa"],
"created":"2014-05-20T15:52:41+0000",
"complete":false,
"description":"Created by David Chase. With James Gandolfini, Lorraine Bracco, Edie Falco, Michael Imperioli. Modern day morality tale about New Jersey mob boss Tony Soprano, as he deals with personal and professional issues in his home and business life.",
"name":"The Sopranos",
"writers":["David Chase","Terence Winter","Matthew Weiner","Diane Frolov","Andrew Schneider"],
"uuid":"4731550a-daaf-4b48-8f6b-bb69c0267547",
"directors":["Alan Taylor","Danny Leiner","John Patterson","Tim Van Patten","David Nutter","Mike Figgis","Steve Buscemi","Steve Shill","Rodrigo Garcia","Jack Bender","Allen Coulter","Peter Bogdanovich"],
"public":true
};