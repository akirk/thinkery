var block = {
"tags":["Shopping"],
"items":[
    {
    "complete":false,
    "name":"4 1\/4 cups all-purpose flour"
    },
    {
    "complete":false,
    "name":"2 (.25 ounce) packages active dry yeast"
    },
    {
    "complete":false,
    "name":"1 1\/2 cups warm water (110 degrees F\/45 degrees C)"
    },
    {
    "complete":false,
    "name":"3 tablespoons white sugar"
    },
    {
    "complete":false,
    "name":"1 tablespoon salt"
    },
    {
    "complete":false,
    "name":"1 tablespoon white sugar"
    }],
"complete":false,
"created":"2014-05-20T17:34:41+0000",
"liked":false,
"name":"Shopping list",
"notebooks":["47317160-1118-4a9a-83d9-8c3acfd4b8e7"],
"image":null,
"uuid":"47344ae9-acb8-46e7-8da0-e9ccf689416a",
"public":true,
"type":"CheckList",
"modified":"2014-05-20T17:35:12+0000"
};