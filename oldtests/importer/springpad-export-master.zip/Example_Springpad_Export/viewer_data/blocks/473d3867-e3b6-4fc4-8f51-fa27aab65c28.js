var block = {
"tags":["video-tag"],
"videos":["https:\/\/www.youtube.com\/v\/YigKNDHhjTA?version=3&f=videos&app=youtube_gdata"],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":"https:\/\/i1.ytimg.com\/vi\/YigKNDHhjTA\/0.jpg",
"type":"Video",
"url":"https:\/\/www.youtube.com\/watch?v=YigKNDHhjTA&feature=youtube_gdata_player",
"modified":"2014-05-19T14:08:05+0000",
"created":"2014-05-19T14:07:57+0000",
"complete":false,
"description":"FREE Download: http:\/\/www.mediafire.com\/?oj4x2qokmsner8u\n\nCover \/ Remix of \"All of the Lights\" (originally by Kanye West) performed by The Northern Lights. The Northern Lights is: Kyle Lampert, producer; Riki Lavi, vocalist; and MCs Jahizzi and Sheck, also of Divine Rhyme.\n\nOur 2010 album on iTunes:\nhttp:\/\/itunes.apple.com\/us\/album\/journey-through-your-minds\/id353700260\n\nFree ALBUM downloads from The Northern Lights and Divine Rhyme available at\nhttp:\/\/www.TheNorthernLights.bandcamp.com\nhttp:\/\/www.DivineRhyme.bandcamp.com\n\nFollow us on Facebook: http:\/\/www.facebook.com\/TNLexperience",
"name":"All of the Lights - kanye west cover (by The Northern Lights)",
"uuid":"473d3867-e3b6-4fc4-8f51-fa27aab65c28",
"rating":0.0,
"public":true,
"comments":[
    {
    "commenter":"klmprt",
    "date":"2014-05-19T14:07:58+0000",
    "comment":"VIdeo comment"
    }]
};