var block = {
"tags":["tasktag"],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"type":"Task",
"date":"2019-05-20T04:00:00+0000",
"modified":"2014-05-19T13:55:36+0000",
"created":"2014-05-19T13:55:11+0000",
"complete":false,
"description":"task due in the future",
"name":"task",
"uuid":"4732cae2-9bf6-48c7-8968-7a5ef2dd5a7d",
"public":true
};