var block = {
"tags":[],
"enabled":true,
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"repeats":
  {
  "text":"every year",
  "repeat every":1,
  "repeats":"Yearly",
  "type":"Frequency"
  },
"type":"Alarm",
"date":"2017-05-20T16:30:00+0000",
"modified":"2014-05-20T16:08:18+0000",
"created":"2014-05-20T16:08:05+0000",
"complete":false,
"name":"Alarm repeats yearly",
"uuid":"4731c168-484a-418f-bc4c-b423d23e0543",
"public":true
};