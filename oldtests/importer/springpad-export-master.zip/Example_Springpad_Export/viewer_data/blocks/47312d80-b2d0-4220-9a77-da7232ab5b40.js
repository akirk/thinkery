var block = {
"tags":[],
"text":"Don't forget the milk!",
"complete":false,
"created":"2014-05-20T15:59:33+0000",
"liked":false,
"name":"Note with reminders",
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"uuid":"47312d80-b2d0-4220-9a77-da7232ab5b40",
"public":true,
"type":"Note",
"modified":"2014-05-20T16:02:33+0000"
};