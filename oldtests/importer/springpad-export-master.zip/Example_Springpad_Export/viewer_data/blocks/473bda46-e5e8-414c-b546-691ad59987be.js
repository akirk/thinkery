var block = {
"tags":[],
"enabled":true,
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"repeats":
  {
  "text":"weekdays",
  "repeats":"Weekdays",
  "type":"Frequency"
  },
"type":"Alarm",
"date":"2019-05-20T16:00:00+0000",
"modified":"2014-05-20T15:59:23+0000",
"created":"2014-05-20T15:58:53+0000",
"complete":false,
"name":"Alarm weekdays repeats",
"uuid":"473bda46-e5e8-414c-b546-691ad59987be",
"notes":"Alarm weekdays-repeating message",
"public":true
};