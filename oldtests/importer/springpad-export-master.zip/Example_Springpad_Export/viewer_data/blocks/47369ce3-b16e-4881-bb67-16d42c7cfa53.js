var block = {
"tags":["note-body","note-with-url","note-tag"],
"text":"note body<br>www.google.com<br>end of note body",
"complete":false,
"created":"2014-05-19T13:54:13+0000",
"liked":false,
"name":"note title",
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"uuid":"47369ce3-b16e-4881-bb67-16d42c7cfa53",
"public":true,
"type":"Note",
"modified":"2014-05-19T13:56:23+0000"
};