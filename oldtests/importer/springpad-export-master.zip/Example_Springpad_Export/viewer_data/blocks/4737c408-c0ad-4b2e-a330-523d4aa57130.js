var block = {
"tags":[],
"liked":false,
"notebooks":["47317160-1118-4a9a-83d9-8c3acfd4b8e7"],
"image":"http:\/\/www.epicurious.com\/images\/recipesmenus\/2006\/2006_august\/235617_116.jpg",
"type":"Recipe",
"url":"http:\/\/www.epicurious.com\/recipes\/food\/views\/Black-Bottom-Peanut-Butter-Mousse-Pie-235617",
"modified":"2014-05-20T17:34:33+0000",
"directions":"1. Preheat oven to 350°F. Spray 9-inch-diameter glass pie dish with nonstick spray. Blend graham crackers, melted butter, and 2 tablespoons sugar in processor until moist clumps form. Press crumb mixture over bottom and up sides of prepared pie dish. Bake crust until lightly browned, about 15 minutes.\n\n2. Meanwhile, combine chocolate chips, 2\/3 cup cream, corn syrup, and  1 teaspoon vanilla in microwave-safe bowl. Microwave on medium heat until chocolate softens, about 3 minutes. Whisk until melted and smooth. Spread chocolate mixture over bottom of crust. Freeze 10 minutes.\n\n3. Microwave peanut butter chips and 3\/4 cup cream in large microwave-safe bowl on medium heat at 15-second intervals just until chips soften, stirring often. Whisk in peanut butter and 1 teaspoon vanilla. Cool to barely lukewarm. Beat remaining 1 cup cream and 2 tablespoons sugar in medium bowl until very thick but not yet holding peaks; fold into peanut butter mixture in 3 additions. Spoon mousse over chocolate layer. Chill at least 1 hour and up to 1 day.",
"source":"http:\/\/www.epicurious.com\/recipes\/food\/views\/Black-Bottom-Peanut-Butter-Mousse-Pie-235617",
"created":"2014-05-20T17:34:02+0000",
"complete":true,
"name":"Black-Bottom Peanut Butter Mousse Pie Black-Bottom Peanut Butter Mousse Pie",
"uuid":"4737c408-c0ad-4b2e-a330-523d4aa57130",
"rating":1.0,
"public":true,
"comments":[
    {
    "commenter":"klmprt",
    "date":"2014-05-20T17:34:32+0000",
    "comment":"Not so good."
    }]
};