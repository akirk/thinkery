var block = {
"region":"USA",
"tags":[],
"vintage":"2009",
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":"http:\/\/ei.isnooth.com\/multimedia\/6\/4\/b\/image_1247193.jpeg",
"type":"Wine",
"url":"http:\/\/www.wine.com\/V6\/Layer-Cake-Virgin-Chardonnay-2009\/wine\/105964\/detail.aspx",
"modified":"2014-05-20T15:52:54+0000",
"varietal":"Chardonnay",
"price":"12.99",
"created":"2014-05-20T15:52:54+0000",
"complete":false,
"name":"Layer Cake Chardonnay",
"uuid":"473478de-f3fd-47ab-af2b-d0e6c53693f9",
"public":true,
"wine type":"White Wine"
};