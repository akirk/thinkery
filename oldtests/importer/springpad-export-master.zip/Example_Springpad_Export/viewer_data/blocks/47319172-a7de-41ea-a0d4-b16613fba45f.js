var block = {
"tags":[],
"liked":false,
"notebooks":["47376d48-7209-4276-a102-b0bfc9f92402"],
"image":"http:\/\/cdn-9.nflximg.com\/us\/boxshots\/ghd\/594689.jpg",
"type":"Movie",
"plot":"Sarah Jessica Parker, Bette Midler and Kathy Najimy star in this supernatural family comedy as a trio of 17th-century sibling witches who are accidentally resurrected in the 20th century by teenager Max.",
"modified":"2014-02-05T16:10:47+0000",
"cast":["Bette Midler","Sarah Jessica Parker","Kathy Najimy","Thora Birch","Omri Katz","Vinessa Shaw"],
"created":"2014-02-05T16:10:46+0000",
"complete":false,
"description":"Hocus Pocus is a 1993 Halloween-themed fantasy\/comedy film that was released by Disney and directed by Kenny Ortega. The film tells the story of a Halloween-hating teenager named Max, who inadvertently resurrects three witches, The Sanderson Sisters, from their temporary death and must risk his life to protect his sister and defeat them with the help of a classmate crush and an immortal black cat.PlotThe film starts in 1693 in Salem, Massachusetts, with teenaged Zachary Binx being awoken by an old woman passing his window and then comes to realize that his younger sister, Emily, is missing. After investigating outside he sees Emily being lured towards the nearby woods by the woman. After chasing her, Binx comes across a cottage. He secretly enters the building to find his sister being surrounded by three witch sisters, Winifred, Sarah, and Mary Sanderson. However, he has arrived too late to find that the sisters have absorbed the life force out of the young girl, resulting in the once old women becoming younger again. Losing in a scuffle with the three witches, and as punishment, Thackery is turned into a black cat doomed to live forever with the guilt of not being able to save his sister, which amuses the witches. Their games end suddenly when the local townspeople, led by Binx's parents, apprehend the three women and hang them for their crimes. Before they die however, Winnie vows that they will return on a Halloween night after being awoken from death by a virgin.Fast forward to Halloween 1993, exactly 300 years later. Max Dennison is a teenager who has been forced to move away with his family from his beloved hometown of Los Angeles, California to Salem. Having just heard the story of the witches, a story that everyone in the town knows and loves, he shows he is less than impressed with it and the holiday itself. His younger sister, Dani, on the other hand, isn't having nearly as hard a time coping as her brother and is getting ready for a night of trick or treating.",
"name":"Hocus Pocus",
"uuid":"47319172-a7de-41ea-a0d4-b16613fba45f",
"rated":"PG",
"directors":["Kenny Ortega"],
"public":false,
"producers":["Steven Haft and David Kirschner"]
};