var block = {
"tags":[],
"enabled":false,
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"repeats":
  {
  "text":"every 2 days",
  "repeat every":2,
  "repeats":"Daily",
  "type":"Frequency"
  },
"type":"Alarm",
"date":"2019-05-20T16:30:00+0000",
"modified":"2014-05-20T16:06:48+0000",
"created":"2014-05-20T16:06:29+0000",
"complete":false,
"name":"Alarm repeats daily, every 2 days",
"uuid":"473c1118-10fe-4243-905d-6fd1296954bf",
"notes":"",
"public":true
};