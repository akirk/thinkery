var block = {
"tags":["music-tag"],
"genres":["Alternative"],
"release date":"1\/1\/2008",
"videos":["https:\/\/www.youtube.com\/v\/QxYemY8CQaw?version=3&f=videos&app=youtube_gdata","https:\/\/www.youtube.com\/v\/hwZhJZCBSos?version=3&f=videos&app=youtube_gdata"],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":"http:\/\/ecx.images-amazon.com\/images\/I\/61EROeqAf-L.jpg",
"type":"Album",
"modified":"2014-05-19T14:08:51+0000",
"created":"2014-05-19T14:08:34+0000",
"complete":false,
"name":"In Rainbows",
"uuid":"473dba7e-566c-476a-bcf0-9e815f7db21f",
"artist":"Radiohead",
"public":true,
"comments":[
    {
    "commenter":"klmprt",
    "date":"2014-05-19T14:08:35+0000",
    "comment":"radiohead"
    }]
};