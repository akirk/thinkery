var block = {
"tags":[],
"liked":false,
"notebooks":["473e67fb-e2a5-4952-bc2f-9c7a0ae1f6f0"],
"image":"http:\/\/ecx.images-amazon.com\/images\/I\/31nY6vHstsL.jpg",
"type":"Product",
"modified":"2014-05-20T16:10:06+0000",
"category":"Home",
"price":"$80.00",
"created":"2014-05-20T16:10:06+0000",
"complete":false,
"manufacturer":"Winsome Wood",
"description":"Handsome and simple console \/ hall table with one drawe. Shaker style in antique walut finish. Assembly required.",
"name":"Winsome Wood Rochester Console Table with one Drawer Shaker",
"uuid":"473df12c-9aae-44ce-bd2b-cdf59ff6b9be",
"public":false
};