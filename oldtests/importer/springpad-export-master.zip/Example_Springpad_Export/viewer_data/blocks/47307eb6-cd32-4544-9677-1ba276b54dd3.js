var block = {
"tags":[],
"created":"2014-05-19T13:54:09+0000",
"item count":29.0,
"liked":false,
"name":"Every Springpad Type!",
"image":null,
"uuid":"47307eb6-cd32-4544-9677-1ba276b54dd3",
"public":true,
"type":"Notebook",
"modified":"2014-05-20T17:58:16+0000"
};