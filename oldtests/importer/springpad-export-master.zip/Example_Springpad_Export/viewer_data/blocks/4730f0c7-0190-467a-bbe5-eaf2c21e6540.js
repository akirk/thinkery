var block = {
"tags":["place-tag"],
"liked":true,
"notebooks":["473c76db-e661-4c03-9b8e-bedaafd1cc62","47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":"http:\/\/mrtopp.com\/wp-content\/uploads\/2009\/11\/missile_defense.jpg",
"phone numbers":
  {
  "phone":"6172410266"
  },
"type":"Business",
"url":"http:\/\/maps.google.com\/maps\/place?cid=7402363843766643634",
"modified":"2014-05-20T16:04:39+0000",
"created":"2014-02-05T18:33:32+0000",
"complete":true,
"name":"Sergeant Russell E",
"uuid":"4730f0c7-0190-467a-bbe5-eaf2c21e6540",
"rating":4.0,
"addresses":
  {
  "address":"1 Thompson Sq Ste 105, Charlestown, MA 02129"
  },
"public":true,
"comments":[
    {
    "commenter":"klmprt",
    "date":"2014-05-20T16:04:36+0000",
    "comment":"A short review of this wonderful tavern."
    },
    {
    "commenter":"klmprt",
    "date":"2014-05-19T13:57:20+0000",
    "comment":"Place comment"
    }]
};