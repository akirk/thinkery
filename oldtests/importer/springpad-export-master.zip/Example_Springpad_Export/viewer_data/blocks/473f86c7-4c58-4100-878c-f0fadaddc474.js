var block = {
"tags":[],
"allDay":true,
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"repeats":
  {
  "text":"every year",
  "repeat every":1,
  "repeats":"Yearly",
  "type":"Frequency"
  },
"date":"2019-05-20T14:00:00+0000",
"type":"Event",
"modified":"2014-05-20T16:04:08+0000",
"created":"2014-05-20T16:03:33+0000",
"complete":false,
"name":"New Event",
"uuid":"473f86c7-4c58-4100-878c-f0fadaddc474",
"rating":3.0,
"public":true
};