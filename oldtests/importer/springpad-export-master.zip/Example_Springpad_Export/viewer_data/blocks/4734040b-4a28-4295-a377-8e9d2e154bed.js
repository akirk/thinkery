var block = {
"tags":[],
"videos":["https:\/\/www.youtube.com\/v\/qj0E6w81nb8?version=3&f=videos&app=youtube_gdata"],
"liked":false,
"notebooks":["47373487-fd4f-403c-9ce7-325ca6c15ec7"],
"image":"https:\/\/i1.ytimg.com\/vi\/qj0E6w81nb8\/0.jpg",
"type":"Video",
"url":"https:\/\/www.youtube.com\/watch?v=qj0E6w81nb8&feature=youtube_gdata_player",
"modified":"2014-02-05T03:50:56+0000",
"created":"2014-02-05T03:50:56+0000",
"complete":false,
"description":"Springpad is your free, easy-to-use personal assistant app that helps you not only remember what's important to you, but also get things done. Visit www.springpad.com for more.",
"name":"What is Springpad? (video)",
"uuid":"4734040b-4a28-4295-a377-8e9d2e154bed",
"public":false
};