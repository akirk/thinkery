var block = {
"tags":[],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":"attachments\/ZyZ3GwCDRrKVJu7rg2Zg_download-by-jon-phillips.jpg",
"type":"Photo",
"url":"attachments\/ZyZ3GwCDRrKVJu7rg2Zg_download-by-jon-phillips.jpg",
"modified":"2014-05-20T15:54:07+0000",
"created":"2014-05-20T15:53:29+0000",
"complete":false,
"description":"Picture description.",
"name":"Photo Type",
"uuid":"473fa68c-b2a1-4918-97c4-ff3c9f0d725a",
"rating":0.0,
"public":true
};