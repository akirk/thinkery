var block = {
"tags":[],
"enabled":false,
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"repeats":
  {
  "text":"never",
  "repeats":"Never",
  "type":"Frequency"
  },
"type":"Alarm",
"date":"2019-05-20T15:30:00+0000",
"modified":"2014-05-20T15:58:45+0000",
"created":"2014-05-20T15:58:04+0000",
"complete":false,
"name":"Alarm (no repeats)",
"uuid":"47338a83-ce4e-45ed-b257-342f931aa24a",
"notes":"Alarm (no repeats) message",
"public":true
};