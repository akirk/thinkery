var block = {
"tags":["recipe-notebook-tag"],
"created":"2014-03-12T17:07:40+0000",
"item count":5.0,
"liked":false,
"name":"Recipes",
"image":null,
"uuid":"47317160-1118-4a9a-83d9-8c3acfd4b8e7",
"public":true,
"type":"Notebook",
"modified":"2014-05-20T17:35:42+0000"
};