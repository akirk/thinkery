var block = {
"tags":[],
"text":"A28NH88F92",
"complete":false,
"created":"2014-05-20T16:08:40+0000",
"liked":false,
"name":"Home depot part number",
"notebooks":["473e67fb-e2a5-4952-bc2f-9c7a0ae1f6f0"],
"image":null,
"uuid":"47344766-91e2-4aa4-956e-5bbfe001f838",
"public":false,
"type":"Note",
"modified":"2014-05-20T16:08:54+0000"
};