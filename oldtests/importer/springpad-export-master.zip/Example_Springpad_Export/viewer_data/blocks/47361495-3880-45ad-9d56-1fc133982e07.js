var block = {
"tags":[],
"items":[
    {
    "complete":false,
    "name":"Install the app on your iPhone, iPad or Android device"
    },
    {
    "complete":false,
    "name":"Save something from another website with the web clipper"
    },
    {
    "complete":false,
    "name":"Create a notebook for an upcoming project"
    },
    {
    "complete":false,
    "name":"Add a note or a task for something you need to get done"
    },
    {
    "complete":false,
    "name":"Add a movie or a book you want to check out"
    }],
"complete":false,
"created":"2014-02-05T03:50:56+0000",
"liked":false,
"name":"Things to try on Springpad",
"notebooks":["47373487-fd4f-403c-9ce7-325ca6c15ec7"],
"image":null,
"uuid":"47361495-3880-45ad-9d56-1fc133982e07",
"public":false,
"type":"CheckList",
"modified":"2014-02-05T03:50:56+0000"
};