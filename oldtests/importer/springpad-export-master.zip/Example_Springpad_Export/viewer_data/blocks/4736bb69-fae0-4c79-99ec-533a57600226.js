var block = {
"tags":[],
"accounts":
  {
  "Email":"ceo@springpad.com",
  "Website":"springpad.com"
  },
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"phone numbers":
  {
  "Phone":"555-555-5555"
  },
"type":"Contact",
"modified":"2014-05-20T15:57:57+0000",
"title":"CEO",
"created":"2014-05-20T15:56:46+0000",
"complete":false,
"name":"Contact",
"company":"Springpad",
"uuid":"4736bb69-fae0-4c79-99ec-533a57600226",
"addresses":
  {
  "Address":"1 Thompson Sq, Charlestown, MA"
  },
"public":true
};