var block = {
"tags":[],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"type":"Task",
"date":"2018-05-20T04:00:00+0000",
"modified":"2014-05-20T17:40:10+0000",
"created":"2014-05-20T17:39:54+0000",
"complete":false,
"description":"This task is not yet complete.",
"name":"Uncompleted task",
"uuid":"47341c98-3805-47ec-8958-8cc06e0f240a",
"public":true
};