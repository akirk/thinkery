var block = {
"tags":[],
"created":"2014-02-05T03:50:55+0000",
"item count":3.0,
"liked":false,
"name":"My First Notebook",
"image":null,
"uuid":"47373487-fd4f-403c-9ce7-325ca6c15ec7",
"public":false,
"type":"Notebook",
"modified":"2014-05-20T18:06:03+0000"
};