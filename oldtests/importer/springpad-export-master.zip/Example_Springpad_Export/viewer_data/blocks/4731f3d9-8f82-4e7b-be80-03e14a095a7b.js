var block = {
"tags":[],
"text":"<b>Every day life, done better. <\/b> Springpad is the best way to save things you want to remember and organize them into notebooks for yourself or to share.<br><br><b>Try all the apps:<\/b><br>Web: http:\/\/springpad.com<br>iPhone\/iPad: <a href=\"https:\/\/itunes.apple.com\/us\/app\/springpad\/id360116898\">Download here<\/a><br>Android: <a href=\"https:\/\/play.google.com\/store\/apps\/details?id=com.springpad\">Download here<\/a><br>Install the web clipper: <a href=\"https:\/\/springpad.com\/resources\/\">Instructions here<\/a><br>Get the Chrome browser extension: <a href=\"https:\/\/chrome.google.com\/webstore\/detail\/springpad-clipper\/eclcnlepmfepnccogfjdafhhlgcfdmnj?hl=en\">Install here<\/a><br><br><b>Get in touch:<\/b><br>Contact the team on <a href=\"https:\/\/www.facebook.com\/springpad\">Facebook<\/a>, <a href=\"https:\/\/www.twitter.com\/springpad\">Twitter<\/a>, or <a href=\"https:\/\/plus.google.com\/+Springpad\/\">G+<\/a><br><br><b>Tips &amp; Features:<\/b><br><a href=\"http:\/\/springpad.com\/blog\">Springpad Blog<\/a><br><br><b>Get Help:<\/b><br>Send us an email at feedback@springpad.com<br><a href=\"http:\/\/springpad.com\/support\">User Support and FAQ<\/a><br><br><b>Find inspiration:<\/b><br><a href=\"http:\/\/springpad.com\/#!\/SpringpadTeam\">Check out these sample notebook ideas<\/a><br><br>",
"complete":false,
"created":"2014-02-05T03:50:56+0000",
"liked":false,
"name":"Learn more about Springpad",
"notebooks":["47373487-fd4f-403c-9ce7-325ca6c15ec7"],
"image":null,
"uuid":"4731f3d9-8f82-4e7b-be80-03e14a095a7b",
"public":false,
"type":"Note",
"modified":"2014-02-05T03:50:56+0000"
};