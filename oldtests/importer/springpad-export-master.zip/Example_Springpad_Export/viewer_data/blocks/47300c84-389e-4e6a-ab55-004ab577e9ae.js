var block = {
"tags":[],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":null,
"type":"Task",
"date":"2014-05-19T04:00:00+0000",
"modified":"2014-05-20T17:39:46+0000",
"created":"2014-05-20T17:39:24+0000",
"complete":true,
"description":"Complete this task!",
"name":"Completed task",
"uuid":"47300c84-389e-4e6a-ab55-004ab577e9ae",
"public":true
};