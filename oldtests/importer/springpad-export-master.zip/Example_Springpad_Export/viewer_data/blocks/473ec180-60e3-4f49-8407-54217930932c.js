var block = {
"tags":["movie-tag"],
"release date":"6\/30\/2006",
"videos":["https:\/\/www.youtube.com\/v\/cTUfeNzhrLA?version=3&f=videos&app=youtube_gdata","http:\/\/a1145.v.phobos.apple.com\/us\/r1000\/034\/Video\/db\/3f\/28\/mzm.srzhacyv..640x366.h264lc.d2.p.m4v"],
"liked":false,
"notebooks":["47376d48-7209-4276-a102-b0bfc9f92402","47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":"http:\/\/cdn-9.nflximg.com\/us\/boxshots\/ghd\/70044889.jpg",
"type":"Movie",
"plot":"After taking a job in the Big Apple as assistant to powerful fashion magazine editor Miranda Priestly, small-town girl Andrea is thrilled, until the magic wears off. She's left feeling battered, used and wondering whether the hard work will pay off.",
"modified":"2014-05-20T17:35:40+0000",
"cast":["Anne Hathaway","Meryl Streep","Adrian Grenier","Simon Baker","Tracie Thoms","Emily Blunt","Jaclynn Tiffany Brown","Rebecca Mader","Stanley Tucci"],
"created":"2014-02-05T16:10:51+0000",
"complete":false,
"description":"The Devil Wears Prada is a 2006 comedy-drama film, a loose screen adaptation of Lauren Weisberger's 2003 novel of the same name. It stars Anne Hathaway as Andrea Sachs, a recent college graduate who goes to New York City and gets a job as a co-assistant to powerful and demanding fashion magazine editor Miranda Priestly, played by Meryl Streep. Emily Blunt and Stanley Tucci co-star in support of the two leads, as catty co-assistant Emily Charlton, and critical yet supportive Art Director Nigel, respectively. Adrian Grenier, Simon Baker and Tracie Thoms play key supporting roles. Wendy Finerman produced and David Frankel directed; the film was distributed by 20th Century Fox.",
"name":"The Devil Wears Prada",
"writers":["Aline Brosh McKenna (screenplay)","Lauren Weisberger (novel)"],
"uuid":"473ec180-60e3-4f49-8407-54217930932c",
"rated":"PG-13",
"directors":["David Frankel"],
"public":true,
"comments":[
    {
    "commenter":"klmprt",
    "date":"2014-05-19T13:58:27+0000",
    "comment":"Comment on a movie"
    }]
};