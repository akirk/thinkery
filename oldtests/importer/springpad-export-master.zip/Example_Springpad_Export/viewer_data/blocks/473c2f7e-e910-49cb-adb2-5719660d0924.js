var block = {
"tags":[],
"liked":false,
"notebooks":["47307eb6-cd32-4544-9677-1ba276b54dd3"],
"image":"https:\/\/lh3.ggpht.com\/_KpKlPENmsDmqjQQYBxpduXY4kaXgaL-n3H14teY-bchlETc5pJU3GG0XUTrscHBWh8=w300",
"type":"Bookmark",
"url":"https:\/\/play.google.com\/store\/apps\/details?id=com.google.android.apps.magazines",
"modified":"2014-05-20T15:52:19+0000",
"created":"2014-05-20T15:52:19+0000",
"complete":false,
"name":"Google Play Newsstand - Android Apps on Google Play",
"uuid":"473c2f7e-e910-49cb-adb2-5719660d0924",
"rating":0.0,
"public":true
};