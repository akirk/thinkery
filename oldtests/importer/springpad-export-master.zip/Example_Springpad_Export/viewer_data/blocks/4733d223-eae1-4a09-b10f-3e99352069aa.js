var block = {
"tags":["tasks"],
"liked":false,
"notebooks":["473e67fb-e2a5-4952-bc2f-9c7a0ae1f6f0"],
"image":null,
"type":"Task",
"date":"2014-05-19T04:00:00+0000",
"modified":"2014-05-20T16:10:51+0000",
"created":"2014-05-20T16:10:10+0000",
"complete":false,
"description":"Task: Fix the fence outside where it was blown over by the storm.",
"name":"Fix the fence outside",
"uuid":"4733d223-eae1-4a09-b10f-3e99352069aa",
"public":false
};